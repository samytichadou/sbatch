import bpy

class SBATCH_UL_batch_entries(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname):
        layout.prop(item, "name", text="", emboss=False)
        if item.entry_type == "FILE":
            icon="FILE"
        else:
            icon="FILE_FOLDER"
        layout.label(text="", icon=icon)

class SBATCH_PF_addon_prefs(bpy.types.AddonPreferences) :
    bl_idname = __package__

    sbatchs: bpy.props.CollectionProperty(
        type = SBATCH_PR_sbatch_preset,
        name="SBatch Presets",
    )
    sbatch_index: bpy.props.IntProperty(default = -1, min = -1)

    def draw(self, context) :
        layout = self.layout
        layout.template_list(
            "SBATCH_UL_batch_entries",
            "",
            self,
            "sbatchs",
            self,
            "sbatch_index",
            rows=5,
        )


# get addon preferences
def get_addon_preferences():
    addon = bpy.context.preferences.addons.get(__package__)
    return getattr(addon, "preferences", None)


### REGISTER ---
def register():
    bpy.utils.register_class(SBATCH_UL_batch_entries)
    bpy.utils.register_class(SBATCH_PF_addon_prefs)

def unregister():
    bpy.utils.unregister_class(SBATCH_UL_batch_entries)
    bpy.utils.unregister_class(SBATCH_PF_addon_prefs)
