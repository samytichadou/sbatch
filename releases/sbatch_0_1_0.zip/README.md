# sbatch
Blender addon to apply script to multiple files
